x = lambda a,b : a * b

print(x(10,5))